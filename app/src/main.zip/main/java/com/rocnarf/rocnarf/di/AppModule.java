package com.rocnarf.rocnarf.di;

import dagger.Module;

@Module(includes = ViewModelModule.class)
public class AppModule {


}
