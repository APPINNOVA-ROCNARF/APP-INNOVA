package com.rocnarf.rocnarf.models;

public class MarkerTag {
    private String codigo;
    private String estado;

    public MarkerTag() {

    }

    public String getCodigo() {
        return codigo;
    }

    public void setCodigo(String codigo) {
        this.codigo = codigo;
    }

    public String getEstado() {
        return estado;
    }

    public void setEstado(String estado) {
        this.estado = estado;
    }
}
