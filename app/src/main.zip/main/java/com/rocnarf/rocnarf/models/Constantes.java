package com.rocnarf.rocnarf.models;

public class Constantes {
    public static final String SP_FILE = "SP_FILE";
    public static final String SP_KEY_DEVICEID = "DEVICEID";
    public static final String SP_KEY_ID = "ID";
}
