package com.rocnarf.rocnarf.models;

import java.util.List;

public class AsesorLocationBulk {
    private List<AsesorLocation> locations;

    public List<AsesorLocation> getLocations() {
        return locations;
    }

    public void setLocations(List<AsesorLocation> locations) {
        this.locations = locations;
    }
}
