package com.rocnarf.rocnarf.di;



import dagger.Component;

@Component(modules = AppModule.class)
public interface AppComponent {


}
